/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencia;

/**
 *
 * @author RPR-C80A404ES
 */
public class vehiculos {
    private String id_vehiculos;
    private String motocicletas;
    private String sidexside;
    private String acuaticas;

    public String getId_vehiculos() {
        return id_vehiculos;
    }

    public String getMotocicletas() {
        return motocicletas;
    }

    public String getSidexside() {
        return sidexside;
    }

    public String getAcuaticas() {
        return acuaticas;
    }

    public vehiculos(String id_vehiculos, String motocicletas, String sidexside, String acuaticas) {
        this.id_vehiculos = id_vehiculos;
        this.motocicletas = motocicletas;
        this.sidexside = sidexside;
        this.acuaticas = acuaticas;
    }

    public String mostrartab() {
        return "vehiculos{" + "id_vehiculos=" + id_vehiculos + ", motocicletas=" + motocicletas + ", sidexside=" + sidexside + ", acuaticas=" + acuaticas + '}';
    }
}
