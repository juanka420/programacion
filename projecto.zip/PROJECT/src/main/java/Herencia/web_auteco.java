/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencia;

/**
 *
 * @author RPR-C80A404ES
 */
public class web_auteco {

    public web_auteco() {
    }
    private String id_auteco;
    private String vehiculos;
    private String modo_de_pago;
    private String redes_sociales;
    private String ubicacion;

    public web_auteco(String vehiculo, String credito, String redes_sociales, String ubicacion) {
        this.vehiculos = vehiculo;
        this.modo_de_pago = credito;
        this.redes_sociales = redes_sociales;
        this.ubicacion = ubicacion;
    }

    public String getVehiculo() {
        return vehiculos;
    }

    public String getCredito() {
        return modo_de_pago;
    }

    public String getRedes_sociales() {
        return redes_sociales;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String mostrartab() {
        return "auteco{" + "vehiculo=" + vehiculos + ", credito=" + modo_de_pago + ", redes_sociales=" + redes_sociales + ", ubicacion=" + ubicacion + '}';
    }
    
}
