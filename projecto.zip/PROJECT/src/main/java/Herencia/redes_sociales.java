/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencia;

/**
 *
 * @author RPR-C80A404ES
 */
public class redes_sociales {
    private String id_redes_sociales;
    private String instagram;
    private String whatsapp;
    private String facebook;
    private String twitter;
    private String youtube;

    public String getId_redes_sociales() {
        return id_redes_sociales;
    }

    public String getInstagram() {
        return instagram;
    }

    public String getWhatsapp() {
        return whatsapp;
    }

    public String getFacebook() {
        return facebook;
    }

    public String getTwitter() {
        return twitter;
    }

    public String getYoutube() {
        return youtube;
    }

    public redes_sociales(String id_redes_sociales, String instagram, String whatsapp, String facebook, String twitter, String youtube) {
        this.id_redes_sociales = id_redes_sociales;
        this.instagram = instagram;
        this.whatsapp = whatsapp;
        this.facebook = facebook;
        this.twitter = twitter;
        this.youtube = youtube;
    }

    
    public String mostrartab() {
        return "redes_sociales{" + "id_redes_sociales=" + id_redes_sociales + ", instagram=" + instagram + ", whatsapp=" + whatsapp + ", facebook=" + facebook + ", twitter=" + twitter + ", youtube=" + youtube + '}';
    }
}
