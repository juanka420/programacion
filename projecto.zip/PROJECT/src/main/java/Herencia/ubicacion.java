/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencia;

/**
 *
 * @author RPR-C80A404ES
 */
public class ubicacion {
    private String id_ubicacion;
    private String local;
    private String web_auteco;

    public String getId_ubicacion() {
        return id_ubicacion;
    }

    public String getLocal() {
        return local;
    }

    public String getWeb_auetco() {
        return web_auteco;
    }

    public ubicacion(String id_ubicacion, String local, String web_auteco) {
        this.id_ubicacion = id_ubicacion;
        this.local = local;
        this.web_auteco = web_auteco;
    }

    
    public String mostrartab() {
        return "ubicacion{" + "id_ubicacion=" + id_ubicacion + ", local=" + local + ", web_auetco=" + web_auteco + '}';
    }
    
}
