/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencia;

/**
 *
 * @author RPR-C80A404ES
 */
public class modo_de_pago {
    private String id_modo_de_pago;
    private String efectivo;
    private String tarjeta;

    public String getId_modo_de_pago() {
        return id_modo_de_pago;
    }

    public String getEfectivo() {
        return efectivo;
    }

    public String getTarjeta() {
        return tarjeta;
    }

    public modo_de_pago(String id_modo_de_pago, String efectivo, String tarjeta) {
        this.id_modo_de_pago = id_modo_de_pago;
        this.efectivo = efectivo;
        this.tarjeta = tarjeta;
    }

    public String mostrartab() {
        return "modo_de_pago{" + "id_modo_de_pago=" + id_modo_de_pago + ", efectivo=" + efectivo + ", tarjeta=" + tarjeta + '}';
    }
    
}
